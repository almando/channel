<?php

/**
 * state module configuration.
 *
 * @package    test_laiguAdminTheme
 * @subpackage state
 * @author     Your name here
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class stateGeneratorConfiguration extends BaseStateGeneratorConfiguration
{
}
