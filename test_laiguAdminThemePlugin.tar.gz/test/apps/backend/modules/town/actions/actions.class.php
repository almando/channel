<?php

require_once dirname(__FILE__).'/../lib/townGeneratorConfiguration.class.php';
require_once dirname(__FILE__).'/../lib/townGeneratorHelper.class.php';

/**
 * town actions.
 *
 * @package    test_laiguAdminTheme
 * @subpackage town
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class townActions extends autoTownActions
{
}
