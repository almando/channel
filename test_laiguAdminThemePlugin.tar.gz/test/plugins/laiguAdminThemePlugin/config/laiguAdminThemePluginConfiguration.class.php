<?php

/**
 * laiguAdminThemePlugin configuration.
 * 
 * @package     laiguAdminThemePlugin
 * @subpackage  config
 * @author      Jordi Llonch <jordi@laigu.net>
 */
class laiguAdminThemePluginConfiguration extends sfPluginConfiguration
{
  /**
   * @see sfPluginConfiguration
   */
  public function initialize()
  {
  }
}
