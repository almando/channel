<?php

class StateTable extends Doctrine_Table
{
}
