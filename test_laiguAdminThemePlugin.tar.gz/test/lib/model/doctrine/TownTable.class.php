<?php

class TownTable extends Doctrine_Table
{
}
